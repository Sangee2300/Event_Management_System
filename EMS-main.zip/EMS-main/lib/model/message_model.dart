class Messagedetail{
  String image,name,desc,click;
  Messagedetail({required this.image,required this.name,required this.desc,required this.click});
}